# simple-language-recognizer

### What is it?
Package that recognizes the language of an input string from over 70 languages. The package is probabilistic as the words in the input string are sampled. 

### What languages can it detect?
Afrikaans, Albanian, Amharic, Arabic, Armenian, Azerbaijani, Basque, Belarusian, Bengali, Bulgarian, Burmese, Catalan, Chinese (Simplified), Chinese (Traditional), Croatian, Czech, Danish, Dutch, English, Estonian, Filipino, Finnish, French, German, Greek, Gujarati, Hebrew, Hindi, Hungarian, Icelandic, Indonesian, Irish, Italian, Japanese, Kannada, Kazakh, Khmer, Korean, Kurdish, Kyrgyz, Lao, Latin, Latvian, Ligurian, Lithuanian, Luganda, Luxembourgish, Macedonian, Malay, Malayalam, Marathi, Nepali, Norwegian, Persian, Polish, Portuguese, Romanian, Russian, Scottish Gaelic, Serbian, Sinhala, Slovak, Slovenian, Spanish, Swedish, Tajik, Tamil, Tatar, Telugu, Thai, Tibetan, Tigrinya, Tswana, Turkish, Ukrainian, Urdu, Vietnamese, Yoruba

### Installing
There are installers for Windows, MacOS and Linux ([manylinux](https://github.com/pypa/manylinux)). Manylinux works with multiple Linux distros. To install:
```
pip install simple-language-recognizer
```

### Note for MacOS users:  
If you receive an error like "SyntaxError: Non-UTF-8 code starting with '\xe0'", include the following at the top of your python codes before the import statement.  
```
# -*- coding: utf-8 -*-
```  

### Example
```
from simpleLanguageRecognizer import languageRecognizer

input = "This is an example of a short phrase in English but which is longer than 50 characters."
output = languageRecognizer(input)
print(output)

output = languageRecognizer(input,False,3,0.25)
print(output)
```

### Input arguments
- text (string): The input string.  
- allLanguages (bool) (Optional): True (All languages) / False (Only European/Latin-based languages). The function works faster when allLanguages is set to False.  
- maxResults (int) (Optional): The maximum length of the output array. The output array might be empty if the input string is not recognized.  
- sampleRatio (double) (Optional): Ratio of words being sampled from the input (0.0 - 1.0).   

### Change log
Version 0.0.1: Initial release.  
Version 0.0.2: Readme.md update.   
Version 0.0.3: Available for Windows, Linux and MacOS.  